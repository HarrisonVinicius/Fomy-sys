module.exports = {
  productionSourceMap: false,

  pwa: {
    name: 'FOMY',
    themeColor: '#D81B60',
    msTileColor: '#D81B60'
  }
}